sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("bankfrontend.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  